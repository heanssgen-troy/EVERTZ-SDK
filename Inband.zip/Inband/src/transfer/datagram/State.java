package transfer.datagram;

/**
 * @author Troy Heanssgen
 *
 */
public enum State {
	OPEN,
	CLOSED,
	TRANSFER,
	ERROR,
	READY
}
