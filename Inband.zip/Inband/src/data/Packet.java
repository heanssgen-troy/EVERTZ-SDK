package data;

import metadata.MetadataTag;

public class Packet {
	private int segmentSize;
	private int segmentNumber;
	private MetadataTag[] data;
	
	public Packet(int segSize, int segNum, MetadataTag[] data){
		this.segmentSize = segSize;
		this.segmentNumber = segNum;
		this.data = data;
	}
	public Packet(MetadataTag[] data){
		this.data = data;
	}

	public int getSegmentSize() {
		return segmentSize;
	}

	public int getSegmentNumber() {
		return segmentNumber;
	}

	public MetadataTag[] getData() {
		return data;
	}
}
